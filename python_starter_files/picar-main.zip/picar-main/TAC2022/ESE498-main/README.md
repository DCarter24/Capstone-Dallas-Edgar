# ESE498

The following resources were utilized:

https://github.com/m-lundberg/simple-pid

https://github.com/Slamtec/rplidar_ros
